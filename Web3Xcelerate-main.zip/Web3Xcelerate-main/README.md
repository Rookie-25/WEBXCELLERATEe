# Web3Xcelerate
Web3Xcelerate's frontend only by using HTML CSS
